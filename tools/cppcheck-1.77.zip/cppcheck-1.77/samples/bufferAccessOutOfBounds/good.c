int main()
{
    int a[3];
    int i;
    for (i = 0; i < 3; i++)
        a[i] = 0;
    return a[0];
}
